<?php
session_start();
require 'config.php';
if (isset($_SESSION['user_id'])) {
    header("Location: welcome.php");
    exit;
}

$hata = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
   
    $email = trim($_POST['email'] ?? '');
    $password = trim($_POST['password'] ?? '');

   
    if ($email === '' || $password === '') {
        $hata = "Lütfen tüm alanları doldurun.";
    } else {
        
        try {
            $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ?");
            $stmt->execute([$email]);
            $user = $stmt->fetch();

            if ($user && password_verify($password, $user['password'])) {
                
                $_SESSION['loggedin'] = true;
                $_SESSION['email'] = $user['email'];
                $_SESSION['user_id'] = $user['id'];
                
                header("Location: welcome.php");
                exit();
            } else {
                $hata = "E-posta veya şifre yanlış.";
            }
        } catch (PDOException $e) {
            $hata = "Veritabanı hatası: " . $e->getMessage();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="tr">

<!DOCTYPE html>
<html lang="tr">
<head>
  <meta charset="UTF-8">
  <title>Giriş Yap</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light d-flex justify-content-center align-items-center vh-100">
  <div class="card p-4 shadow" style="max-width: 400px; width:100%;">
    <h3 class="text-center mb-3">Giriş Yap</h3>

    <?php if ($hata): ?>
      <div class="alert alert-danger"><?php echo htmlspecialchars($hata); ?></div>
    <?php endif; ?>

    <form method="post" action="">
      <div class="mb-3">
        <label for="email" class="form-label">Email</label>
        <input
          type="email"
          name="email"
          id="email"
          class="form-control"
          value="<?php echo htmlspecialchars($email ?? ''); ?>"
          required>
      </div>
      <div class="mb-3">
        <label for="password" class="form-label">Şifre</label>
        <input
          type="password"
          name="password"
          id="password"
          class="form-control"
          required>
      </div>
      <button type="submit" class="btn btn-primary w-100">Giriş Yap</button>
    </form>

    <div class="mt-3 text-center">
      <a href="register.php" class="btn btn-link">Hesabın yok mu? Kayıt ol</a>
    </div>
  </div>
</body>
</html>
