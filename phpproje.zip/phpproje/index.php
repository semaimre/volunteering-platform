<?php
session_start();
require 'config.php';
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Anasayfa - Giriş / Kayıt</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" />
    <style>
        body {
            background-color: #f8f9fa;
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
        }
        .container {
            max-width: 350px;
            text-align: center;
            padding: 30px;
            background: white;
            border-radius: 12px;
            box-shadow: 0 4px 20px rgba(0,0,0,0.1);
        }
        .btn {
            width: 100%;
            margin-top: 15px;
            font-size: 1.2rem;
            padding: 10px;
        }
    </style>
</head>
<body>

<div class="container">
    <h2 class="mb-4">Hoşgeldiniz!</h2>

    <?php

    if (isset($_SESSION['error'])) {
        echo '<div class="alert alert-danger">'.htmlspecialchars($_SESSION['error']).'</div>';
        unset($_SESSION['error']);
    }
    if (isset($_SESSION['success'])) {
        echo '<div class="alert alert-success">'.htmlspecialchars($_SESSION['success']).'</div>';
        unset($_SESSION['success']);
    }
    ?>

    <a href="login.php" class="btn btn-primary">Giriş Yap</a>
    <a href="register.php" class="btn btn-success">Kayıt Ol</a>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
