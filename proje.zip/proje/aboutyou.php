<?php
session_start();
include('config.php'); // $pdo PDO bağlantısı

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$userId = $_SESSION['user_id'];
$update_success = false;

// Form gönderildi mi kontrolü
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Formdan gelen değerler
    $fullname = $_POST['fullname'] ?? '';
    $age = $_POST['age'] ?? '';
    $city = $_POST['city'] ?? '';
    $skills = !empty($_POST['skills']) ? implode(',', $_POST['skills']) : '';

    // Veritabanını güncelle
    $stmt = $pdo->prepare("UPDATE volunteers SET fullname = ?, age = ?, skills = ?, city = ? WHERE user_id = ?");
    $stmt->execute([$fullname, $age, $skills, $city, $userId]);

    $update_success = true;
    header("Location: aboutyou.php");
    exit;}

// Güncel kullanıcı bilgilerini veritabanından çek
$stmt = $pdo->prepare("SELECT * FROM volunteers WHERE user_id = ?");
$stmt->execute([$userId]);
$user = $stmt->fetch();

// Formda kullanmak için değerleri ayarla (POST varsa POST'tan, yoksa DB'den)
$fullname = $_POST['fullname'] ?? $user['fullname'] ?? '';
$age = $_POST['age'] ?? $user['age'] ?? '';
$city = $_POST['city'] ?? $user['city'] ?? '';
$skills = [];

if (isset($_POST['skills'])) {
    $skills = $_POST['skills'];
} elseif (!empty($user['skills'])) {
    $skills = explode(',', $user['skills']);
}

// Kullanıcının başvurduğu ilanlar (applications JOIN events)
$stmt = $pdo->prepare("
    SELECT e.id, e.title, e.city, e.category, e.created_at
    FROM applications a
    JOIN events e ON a.event_id = e.id
    WHERE a.user_id = ?
    ORDER BY a.applied_at DESC
");
$stmt->execute([$userId]);
$appliedEvents = $stmt->fetchAll();

// Kullanıcının açtığı ilanlar
$stmt = $pdo->prepare("SELECT * FROM events WHERE user_id = ? ORDER BY created_at DESC");
$stmt->execute([$userId]);
$myEvents = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="tr">
<head>
  <meta charset="UTF-8" />
  <title>Profilim</title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" />
</head>
<body class="bg-light p-4">

<div class="container">

<h2>Kullanıcı Bilgileri</h2>

<?php if (!isset($_GET['edit'])): ?>
    <!-- Sadece yazılı göster -->
    <ul>
        <li>Ad Soyad: <?= htmlspecialchars($fullname) ?></li>
        <li>Yaş: <?= htmlspecialchars($age) ?></li>
        <li>Şehir: <?= htmlspecialchars($city) ?></li>
        <li>Yetenekler: <?= !empty($skills) ? implode(", ", $skills) : 'Yok' ?></li>
    </ul>

    <a href="?edit=1" class="btn btn-primary">Güncelle</a>

<?php else: ?>
    <!-- Güncelleme formu -->
    <form action="" method="POST">
        <div class="mb-3">
            <label for="fullname" class="form-label">Ad Soyad</label>
            <input id="fullname" name="fullname" class="form-control" value="<?= htmlspecialchars($fullname) ?>" />
        </div>

        <div class="mb-3">
            <label for="age" class="form-label">Yaş</label>
            <input id="age" name="age" type="number" class="form-control" value="<?= htmlspecialchars($age) ?>" />
        </div>

        <div class="mb-3">
            <label for="city" class="form-label">Şehir</label>
            <select id="city" name="city" class="form-select">
                <?php
                $cities = ['İstanbul', 'Ankara', 'İzmir', 'Antalya']; 
                foreach ($cities as $c) {
                    $selected = ($c == $city) ? 'selected' : '';
                    echo "<option value='$c' $selected>$c</option>";
                }
                ?>
            </select>
        </div>

        <div class="mb-3">
            <label for="skills" class="form-label">Yetenekler</label><br>
            <?php
            $options = ['Çevre', 'Eğitim', 'Sağlık', 'Hayvan Hakları']; 
            foreach ($options as $opt) {
                $checked = in_array($opt, $skills) ? 'checked' : '';
                echo "<div class='form-check form-check-inline'>";
                echo "<input class='form-check-input' type='checkbox' name='skills[]' value='$opt' $checked id='skill_$opt'>";
                echo "<label class='form-check-label' for='skill_$opt'>$opt</label>";
                echo "</div>";
            }
            ?>
        </div>

        <button type="submit" class="btn btn-primary">Kaydet</button>
        <a href="?" class="btn btn-secondary">Vazgeç</a>
    </form>
<?php endif; ?>

<hr />

<h2>Önceden Başvurduğun İlanlar</h2>
<?php if (count($appliedEvents) > 0): ?>
    <ul class="list-group mb-4">
    <?php foreach ($appliedEvents as $event): ?>
        <li class="list-group-item">
            <strong><?= htmlspecialchars($event['title']) ?></strong><br>
            Şehir: <?= htmlspecialchars($event['city']) ?><br>
            Kategori: <?= htmlspecialchars($event['category']) ?><br>
            İlan Tarihi: <?= htmlspecialchars($event['created_at']) ?>
        </li>
    <?php endforeach; ?>
    </ul>
<?php else: ?>
    <p>Henüz herhangi bir ilana başvuru yapmamışsınız.</p>
<?php endif; ?>

<hr />
...
<h2>Açtığın Gönüllülük İlanları ve Başvuranlar</h2>
<?php if (count($myEvents) > 0): ?>
    <?php foreach ($myEvents as $event): ?>
        <div class="card mb-3 p-3">
            <h5><?= htmlspecialchars($event['title']) ?></h5>
            <p><?= nl2br(htmlspecialchars($event['description'])) ?></p>
            <p><strong>Şehir:</strong> <?= htmlspecialchars($event['city']) ?></p>
            <p><strong>Kategori:</strong> <?= htmlspecialchars($event['category']) ?></p>

            <h6>Başvuranlar:</h6>
            <?php
            $stmt2 = $pdo->prepare("
                SELECT v.id, v.fullname, v.age, v.skills, v.city
                FROM applications a
                JOIN volunteers v ON a.user_id = v.user_id
                WHERE a.event_id = ?
            ");
            $stmt2->execute([$event['id']]);
            $applicants = $stmt2->fetchAll();
            ?>

            <?php if (count($applicants) > 0): ?>
                <ul>
                <?php foreach ($applicants as $applicant): ?>
                    <li>
                        <strong><?= htmlspecialchars($applicant['fullname']) ?></strong>, 
                        Yaş: <?= htmlspecialchars($applicant['age']) ?>, 
                        Şehir: <?= htmlspecialchars($applicant['city']) ?>, 
                        Yetenekler: <?= !empty($applicant['skills']) ? htmlspecialchars($applicant['skills']) : 'Yok' ?>
                    </li>
                <?php endforeach; ?>
                </ul>
            <?php else: ?>
                <p>Henüz başvuran yok.</p>
            <?php endif; ?>
        </div>
    <?php endforeach; ?>
<?php else: ?>
    <p>Henüz herhangi bir gönüllülük ilanı açmamışsınız.</p>
<?php endif; ?>
...

<hr />
<a href="welcome.php" class="btn btn-secondary">Geri dön</a>
<a href="logout.php" class="btn btn-outline-danger ms-2">Çıkış Yap</a>

</div>

</body>
</html>
