<?php
session_start();
require_once "config.php";  // Burada $pdo PDO nesnesi olmalı

$user_id = $_SESSION['user_id'] ?? null;
if ($user_id === null) {
    die("Kullanıcı oturumu bulunamadı. Lütfen giriş yapınız.");
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $event_id = $_POST['event_id'] ?? null;
    if (!$event_id) {
        die("Geçerli bir etkinlik seçiniz.");
    }

    $stmt = $pdo->prepare("INSERT INTO applications (user_id, event_id) VALUES (?, ?)");
    if (!$stmt) {
        die("Sorgu hazırlanamadı.");
    }

    $success = $stmt->execute([$user_id, $event_id]);

    if ($success && $stmt->rowCount() === 1) {
        echo <<<HTML
        <!DOCTYPE html>
        <html lang="tr">
        <head>
            <meta charset="UTF-8">
            <title>Başarılı</title>
            <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
        </head>
        <body class="bg-light d-flex justify-content-center align-items-center vh-100">
            <div class="card p-4 shadow" style="max-width: 500px;">
                <h4 class="text-success">🎉 Gönderim başarılı!</h4>
                <p>Bilgileriniz başarıyla kaydedildi.</p>
                <div class="mt-3 d-flex justify-content-between">
                    <a href="welcome.php" class="btn btn-primary">Anasayfaya Dön</a>
                    <a href="logout.php" class="btn btn-danger">Çıkış Yap</a>
                </div>
            </div>
        </body>
        </html>
        HTML;
    } else {
        $errorInfo = $stmt->errorInfo();
        echo "Başvuru sırasında hata oluştu: " . $errorInfo[2];
    }

} else {
    header("Location: volunteer.php");
    exit();
}
?>
