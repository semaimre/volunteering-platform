<?php
session_start();
require 'config.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit;
}

$error = '';
$success = '';

// Form gönderildiyse
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = $_POST['title'] ?? '';
    $user_id = $_SESSION['user_id']; 
    $description = $_POST['description'] ?? '';
    $city = $_POST['city'] ?? '';
    $category = $_POST['category'] ?? '';
    $min_age = $_POST['min_age'] ?? 0;
    $max_age = $_POST['max_age'] ?? 100;

$stmt = $pdo->prepare("INSERT INTO events (title, description, city, category, min_age, max_age, user_id) VALUES (?, ?, ?, ?, ?, ?, ?)");
$stmt->execute([$title, $description, $city, $category, $min_age, $max_age, $user_id]);

    
    // Başarı mesajı ve yönlendirme butonları
    echo<<<HTML
    <!DOCTYPE html>
    <html lang="tr">
    <head>
        <meta charset="UTF-8">
        <title>Başarılı</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    </head>
    <body class="bg-light d-flex justify-content-center align-items-center vh-100">
        <div class="card p-4 shadow" style="max-width: 500px;">
            <h4 class="text-success">🎉 İlan başarıyla oluşturuldu!</h4>
            <div class="mt-3 d-flex justify-content-between">
                <a href="welcome.php" class="btn btn-primary">Anasayfaya Dön</a>
                <a href="logout.php" class="btn btn-danger">Çıkış Yap</a>
            </div>
        </div>
    </body>
    </html>
    HTML;
    exit; // Çalışmayı sonlandır
} else {
    $error = "Lütfen tüm alanları doldurun.";
}


?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <title>Gönüllü İlanı Oluştur</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f2f2f2;
            padding: 30px;
        }
        .form-container {
            background: white;
            max-width: 600px;
            margin: auto;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        }
        input, textarea, select {
            width: 100%;
            padding: 12px;
            margin-top: 8px;
            margin-bottom: 16px;
            border: 1px solid #ccc;
            border-radius: 6px;
        }
        button {
            background-color: #4CAF50;
            color: white;
            padding: 12px 20px;
            border: none;
            border-radius: 6px;
            cursor: pointer;
        }
        .message {
            margin-bottom: 20px;
            padding: 10px;
            border-radius: 6px;
        }
        .success { background: #d4edda; color: #155724; }
        .error { background: #f8d7da; color: #721c24; }
    </style>
</head>
<body>

<div class="form-container">
    <h2>Gönüllü İlanı Oluştur</h2>

    <?php if ($success): ?>
        <div class="message success"><?= $success ?></div>
    <?php elseif ($error): ?>
        <div class="message error"><?= $error ?></div>
    <?php endif; ?>

    <form method="post">
        <label>Başlık:</label>
        <input type="text" name="title" required>

        <label>Açıklama:</label>
        <textarea name="description" rows="5" required></textarea>

        <label>Şehir:</label>
        <select name="city" required>
            <option value="">Seçiniz</option>
            <option value="İstanbul">İstanbul</option>
            <option value="Ankara">Ankara</option>
            <option value="İzmir">İzmir</option>
            <!-- Diğer şehirler eklenebilir -->
        </select>

        <label>Kategori:</label>
        <select name="category" required>
            <option value="">Seçiniz</option>
            <option value="Eğitim">Eğitim</option>
            <option value="Çevre">Çevre</option>
            <option value="Sağlık">Sağlık</option>
            <option value="Hayvan Hakları">Hayvan Hakları</option>
        </select>

        <label>Minimum Yaş:</label>
        <input type="number" name="min_age" min="0" max="100" required>

        <label>Maksimum Yaş:</label>
        <input type="number" name="max_age" min="0" max="100" required>

        <button type="submit">İlanı Oluştur</button>
    </form>
    

</div>
<div style="display: flex; justify-content: center; gap: 20px; margin-top: 30px;">
  <a href="welcome.php" 
     style="background-color: #0d6efd; color: white; padding: 12px 28px; border-radius: 8px; text-decoration: none; font-weight: 600; box-shadow: 0 4px 8px rgba(13, 110, 253, 0.3); transition: background-color 0.3s ease;">
    Geri Dön
    </a>
</div>

</body>
</html>
