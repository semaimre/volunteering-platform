<?php
session_start();
require 'config.php';

// Giriş kontrolü
if (!isset($_SESSION["user_id"])) {
    header("Location: login.php");
    exit();}


// Filtre verilerini al
$selected_city = $_GET['city'] ?? '';
$selected_categories = $_GET['category'] ?? [];
$age = $_GET['age'] ?? '';


// SQL sorgusu oluştur
$sql = "SELECT * FROM events WHERE 1=1";
$params = [];

if (!empty($selected_city)) {
    $sql .= " AND city = :city";
    $params[':city'] = $selected_city;
}

if (!empty($selected_categories)) {
    $placeholders = [];
    foreach ($selected_categories as $index => $cat) {
        $placeholder = ":cat" . $index;
        $placeholders[] = $placeholder;
        $params[$placeholder] = $cat;
    }
    $sql .= " AND category IN (" . implode(',', $placeholders) . ")";
}


if (is_numeric($age)) {
    $sql .= " AND :age BETWEEN min_age AND max_age";
    $params[':age'] = $age;
}


$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$events = $stmt->fetchAll()
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <title>Gönüllülük İlanları</title>
    <style>
        body {
            font-family: 'Segoe UI', sans-serif;
            background: #f2f2f2;
            margin: 0;
        }
        header {
            background: #4CAF50;
            color: white;
            padding: 15px 30px;
            font-size: 20px;
        }
        .container {
            max-width: 1000px;
            margin: 30px auto;
            padding: 20px;
        }
        .filter-form {
            background: white;
            padding: 20px;
            border-radius: 10px;
            margin-bottom: 25px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        }
        .filter-form label {
            display: block;
            margin: 10px 0 5px;
        }
        .filter-form input[type="text"],
        .filter-form input[type="number"],
        .filter-form select {
            width: 100%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 6px;
        }
        .checkbox-group {
            display: flex;
            flex-wrap: wrap;
            gap: 15px;
            margin-top: 10px;
        }
        .checkbox-group label {
            display: flex;
            align-items: center;
            gap: 5px;
        }
        .filter-form button {
            margin-top: 20px;
            padding: 12px 24px;
            background: #4CAF50;
            color: white;
            border: none;
            border-radius: 6px;
            cursor: pointer;
        }
        .event {
            background: white;
            padding: 20px;
            margin-bottom: 20px;
            border-radius: 10px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        }
        .event h3 {
            margin-top: 0;
        }
        .event button {
            background: #2196F3;
            color: white;
            padding: 10px 15px;
            border: none;
            border-radius: 6px;
            cursor: pointer;
        }
        .event button:hover {
            background: #1976D2;
        }
    </style>
</head>
<body>

<header>Gönüllülük Platformu</header>

<div class="container">
    <form method="get" class="filter-form">
        <label for="city">Şehir:</label>
        <select name="city" id="city">
            <option value="">Tüm Şehirler</option>
            <option value="İstanbul" <?= $selected_city === 'İstanbul' ? 'selected' : '' ?>>İstanbul</option>
            <option value="Ankara" <?= $selected_city === 'Ankara' ? 'selected' : '' ?>>Ankara</option>
            <option value="İzmir" <?= $selected_city === 'İzmir' ? 'selected' : '' ?>>İzmir</option>
            <!-- Diğer şehirler eklenebilir -->
        </select>

        <label>Kategoriler:</label>
        <div class="checkbox-group">
            <?php
            $all_categories = ['Çevre', 'Eğitim', 'Sağlık', 'Hayvan Hakları'];
            foreach ($all_categories as $cat):
            ?>
                <label>
                    <input type="checkbox" name="category[]" value="<?= $cat ?>" <?= in_array($cat, $selected_categories) ? 'checked' : '' ?>>
                    <?= $cat ?>
                </label>
            <?php endforeach; ?>
        </div>

        <label for="age">Yaşınız:</label>
        <input type="number" name="age" id="age" value="<?= htmlspecialchars($age) ?>" min="0">

        <button type="submit">Filtrele</button>
    </form>

    <?php if ($events): ?>
        <?php foreach ($events as $event): ?>
            <div class="event">
                <h3><?= htmlspecialchars($event['title']) ?></h3>
                <p><strong>Şehir:</strong> <?= htmlspecialchars($event['city']) ?></p>
                <p><strong>Kategori:</strong> <?= htmlspecialchars($event['category']) ?></p>
                <p><strong>Yaş Aralığı:</strong> <?= htmlspecialchars($event['min_age']) ?> - <?= htmlspecialchars($event['max_age']) ?></p>
                <p><?= nl2br(htmlspecialchars($event['description'])) ?></p>
                <form action="volunteer_submit.php" method="post">
                    <input type="hidden" name="event_id" value="<?= $event['id'] ?>">
                    <button type="submit">Başvur</button>
                </form>
            </div>
        <?php endforeach; ?>
         <div style="display: flex; justify-content: center; gap: 20px; margin-top: 30px;">
                <a href="welcome.php" 
                 style="background-color: #0d6efd; color: white; padding: 12px 28px; border-radius: 8px; text-decoration: none; font-weight: 600; box-shadow: 0 4px 8px rgba(13, 110, 253, 0.3); transition: background-color 0.3s ease;">
                 Geri Dön
               </a>
                </div>
    <?php else: ?>
        <p>Sonuç bulunamadı.</p>
        <div style="margin-top: 20px;">
        <a href="welcome.php" 
           style="margin-right: 10px; padding: 10px 15px; background:#4CAF50; color:white; text-decoration:none; border-radius:5px;">
           Anasayfaya Dön
        </a>
        <a href="logout.php" 
           style="padding: 10px 15px; background:#f44336; color:white; text-decoration:none; border-radius:5px;">
           Çıkış Yap
        </a>
    </div>
    <?php endif; ?>
</div>

</body>
</html>
