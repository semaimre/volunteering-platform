<?php
require 'config.php';
if (isset($_SESSION['user_id'])) {
    header("Location: welcome.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="tr">
<head>
  <meta charset="UTF-8">
  <title>Giriş / Kayıt</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body {
      background-color: #f8f9fa;
    }
    .card {
      max-width: 400px;
      margin: auto;
      margin-top: 80px;
    }
    .btn-toggle {
      margin: 5px;
    }
  </style>
</head>
<body>

<div class="card shadow">
  <div class="card-body">
    <h4 class="card-title text-center mb-4">Giriş Yap / Kayıt Ol</h4>

    <div class="d-flex justify-content-center mb-3">
      <button class="btn btn-outline-primary btn-toggle" onclick="showForm('login')">Giriş Yap</button>
      <button class="btn btn-outline-success btn-toggle" onclick="showForm('register')">Kayıt Ol</button>
    </div>

    <!-- Giriş Formu -->
    <div id="loginForm">
      <form method="post" action="login.php">
        <div class="mb-3">
          <label class="form-label">E-posta</label>
          <input type="email" class="form-control" name="email" required>
        </div>
        <div class="mb-3">
          <label class="form-label">Şifre</label>
          <input type="password" class="form-control" name="password" required>
        </div>
        <button type="submit" class="btn btn-primary w-100">Giriş Yap</button>
      </form>
    </div>

    <!-- Kayıt Formu -->
    <div id="registerForm" style="display:none;">
      <form method="post" action="register.php">
        <div class="mb-3">
          <label class="form-label">E-posta</label>
          <input type="email" class="form-control" name="email" required>
        </div>
        <div class="mb-3">
          <label class="form-label">Şifre</label>
          <input type="password" class="form-control" name="password" required>
        </div>
        <button type="submit" class="btn btn-success w-100">Kayıt Ol</button>
      </form>
    </div>

  </div>
</div>

<script>
  function showForm(formType) {
    document.getElementById('loginForm').style.display = (formType === 'login') ? 'block' : 'none';
    document.getElementById('registerForm').style.display = (formType === 'register') ? 'block' : 'none';
  }

  // Sayfa yüklendiğinde varsayılan olarak login formunu göster
  window.onload = function () {
    showForm('login');
  }
</script>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>


