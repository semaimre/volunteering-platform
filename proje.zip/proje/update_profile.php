<?php
session_start();
include('config.php'); // config içinde artık `session_start()` OLMAYACAK

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_POST['user_id']; 
$fullname = $_POST['fullname']; 
$age = $_POST['age']; 
$city = $_POST['city']; 
$skills = !empty($_POST['skills']) ? implode(',', $_POST['skills']) : '';

$stmt = $pdo->prepare("UPDATE volunteers SET fullname = ?, age = ?, skills = ?, city = ? WHERE user_id = ?");
$stmt->execute([$fullname, $age, $skills, $city, $user_id]);

header("Location: aboutyou.php"); 
exit();

