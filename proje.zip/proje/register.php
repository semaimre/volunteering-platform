<?php
require_once "config.php";

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["ajax"])) {
    header('Content-Type: application/json');

    $username = trim($_POST["username"] ?? "");
    $email = trim($_POST["email"] ?? "");
    $password = $_POST["password"] ?? "";

    if ($username === "" || $email === "" || $password === "") {
        echo json_encode(["status" => "error", "message" => "Lütfen tüm alanları doldurunuz."]);
        exit;
    }

    $stmt = $conn->prepare("SELECT id FROM users WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        echo json_encode(["status" => "error", "message" => "Bu e-posta zaten kullanılmış."]);
    } else {
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);
        $stmt = $conn->prepare("INSERT INTO users (username, email, password) VALUES (?, ?, ?)");
        $stmt->bind_param("sss", $username, $email, $hashed_password);

        if ($stmt->execute()) {
            echo json_encode(["status" => "success", "message" => "Kayıt başarılı! Giriş sayfasına yönlendiriliyorsunuz."]);
        } else {
            echo json_encode(["status" => "error", "message" => "Kayıt başarısız: " . $stmt->error]);
        }
    }
    exit;
}
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <title>Kayıt Ol</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-5">
    <h2>Kayıt Formu</h2>
    <form id="registerForm">
        <div class="mb-3">
            <label class="form-label">Kullanıcı Adı:</label>
            <input type="text" name="username" class="form-control" required>
        </div>

        <div class="mb-3">
            <label class="form-label">Email:</label>
            <input type="email" name="email" class="form-control" required>
        </div>

        <div class="mb-3">
            <label class="form-label">Şifre:</label>
            <input type="password" name="password" class="form-control" required>
        </div>

        <button type="submit" class="btn btn-primary">Kayıt Ol</button>
    </form>
</div>

<!-- Bootstrap Modal -->
<div class="modal fade" id="messageModal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Bilgi</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Kapat"></button>
      </div>
      <div class="modal-body" id="modalMessage"></div>
    </div>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
document.getElementById("registerForm").addEventListener("submit", function(e) {
    e.preventDefault();

    const formData = new FormData(this);
    formData.append("ajax", "1");

    fetch("register.php", {
        method: "POST",
        body: formData
    })
    .then(res => res.json())
    .then(data => {
        const modal = new bootstrap.Modal(document.getElementById("messageModal"));
        document.getElementById("modalMessage").innerText = data.message;
        modal.show();

        if (data.status === "success") {
            setTimeout(() => window.location.href = "login.php", 2000);
        }
    });
});
</script>
</body>
</html>
